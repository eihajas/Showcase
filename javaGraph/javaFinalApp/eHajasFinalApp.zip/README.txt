Welcome to my app
To build, open command prompt and navigate
to the directory eHajasFinalApp.
From there just type build and then type
run and the program will build itself.